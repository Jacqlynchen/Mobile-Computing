//
//  ContentView.swift
//  Assignment_Week3_Jessica Laurentia Tedja
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ContentView: View { // struct itu immutable
    // Sebuah property wrapper yang membantu
    //    @State private var num = 0 // var immutable
    //    @State private var count = 0
    //    @State private var nama = ""
    //    @State private var totalcount = 0
    
    var body: some View {
        NavigationStack{
            VStack (spacing: 30){
                Text("🏠Home Screen").font(.largeTitle)
                NavigationLink("Go to Details"){
                    DetailsScreen()
                }
                NavigationLink("Show Item"){
                    ItemScreen()
                }
            }
        }
        TabView{
            HomeView()
                .tabItem{
                    Label("Home", systemImage: "house.fill")
                }
                .tag(0)
                .badge(3)
            SearchView()
                .tabItem{
                    Label("Search", systemImage: "magnifyingglass")
                }
            ProfileView()
                .tabItem{
                    Label("Profile", systemImage: "person.circle")
                }
        }
    }
}
    
//        VStack {
//            Text("Hitung : \(count)").font(.largeTitle)
//            Text("Nama : \(nama)")
//            TextField("Isi Nama", text: $nama).textFieldStyle(RoundedBorderTextFieldStyle())
//            
//            HStack{
//                Button("-"){
//                    count -= 1
//                }
//                .font(Font.largeTitle.bold())
//                
//                Button("+"){
//                    count += 1
//                }
//                .font(Font.largeTitle.bold())
//
//            }
//            
//            Button ("Count"){
//                count += 1
//            }
            
//            Button ("Tambah"){
//                num += 1
//            }
//            Text("Hello, world! \(num)")
            
//            Text("Parent View").font(.largeTitle)
//            Text("Total Count : \(totalcount)").font(.title2).padding()
//            
//            CounterView(count: $totalcount ) // manggil COunterview di page lain yang otomatis bakal terupdate jg di halaman ini
//            Spacer()
//            
//        }
//        .padding()
//        .background(.green.opacity(0.6))
//    }
    
struct HomeView:View{
    @State private var textKu = ""
    var body: some View{
        Form{
                VStack{
                    Text("🏡Home!").font(.largeTitle)
                    TextField("Name", text: $textKu).border(.gray)
                }
                .padding()
                .background(.green.opacity(0.6))
            }
        }
        
    }

struct SearchView:View{
    var body: some View{
        VStack{
            Text("🔍Search!").font(.largeTitle)
                }
            }
        }

struct ProfileView:View{
    var body: some View{
        VStack{
            Text("😏Profile!").font(.largeTitle)
                }
            }
        }

struct DetailsScreen:View{
    var body:some View{
        VStack{
            Text("📝Details Screen").font(.largeTitle)
            Text("You come from home screen!")
            
        }
        .navigationTitle("Details")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ItemScreen:View{
    let items = ["Tomato", "Papaya", "Banana"]
    var body:some View{
        VStack{
            // di declare kayak foreach
            List(items, id: \.self){ item in NavigationLink(destination: ItemDetailScreen(item: item))
                {
                    Text(item)
                }
                
            }
            // kaya property tujuannya mau kemana,uda ad navigationlink jdi ga perlu
//            .navigationDestination(for:String.self) {
//                item in ItemDetailScreen(item: item)
            
            .navigationTitle("Items")
        }
   
    }
}
    
struct ItemDetailScreen:View{
    let item : String
    var body:some View{
        NavigationStack{
            VStack{
                Text("Welcome to Item Detail")
                    .font(.title)
                Text("You selected: \(item)")
            }
            .navigationTitle(item)
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
            
    #Preview {
        ContentView()
    }

