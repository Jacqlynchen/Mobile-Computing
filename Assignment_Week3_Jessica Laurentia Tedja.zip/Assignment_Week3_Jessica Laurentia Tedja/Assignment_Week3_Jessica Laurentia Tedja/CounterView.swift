//
//  CounterView.swift
//  Assignment_Week3_Jessica Laurentia Tedja
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct CounterView: View {
    @Binding var count: Int
    // variabelnya bisa di passing antar view (Nilai)
    
    var body: some View {
        VStack{
            Text("Child View (CounterView)").font(.headline)
            HStack{
                Button("-") {
                    count -= 1
                }.buttonStyle(.bordered)
                
                Button("+"){
                    count += 1
                }.buttonStyle(.bordered)
            }
        }
        .padding()
        .background(.red.opacity(0.8))
        .cornerRadius(10)
        
    }
}
