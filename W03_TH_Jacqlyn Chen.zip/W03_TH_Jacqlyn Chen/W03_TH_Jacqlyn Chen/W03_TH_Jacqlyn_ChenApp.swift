//
//  W03_TH_Jacqlyn_ChenApp.swift
//  W03_TH_Jacqlyn Chen
//
//  Created by Jennifer Alicia Litan on 29/09/25.
//

import SwiftUI

@main
struct W03_TH_Jacqlyn_ChenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
