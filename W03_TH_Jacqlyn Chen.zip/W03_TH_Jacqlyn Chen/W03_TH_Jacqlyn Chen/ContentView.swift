//
//  ContentView.swift
//  W03_TH_Jacqlyn Chen
//
//  Created by Jacqlyn Chen Litan on 29/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            
            Text("Coming Soon")
                .tabItem {
                    Image(systemName: "figure.walk")
                    Text("Activity")
                }
            
            Text("Coming Soon")
                .tabItem {
                    Image(systemName: "chart.bar.fill")
                    Text("Stats")
                }
            
            Text("Coming Soon")
                .tabItem {
                    Image(systemName: "gearshape.fill")
                    Text("Settings")
                }
        }
    }
}

struct HomeView: View {
    var body: some View {
        ScrollView {
            VStack (alignment: .leading, spacing: 20){
                
                // Header
                HStack{
                    VStack(alignment: .leading){
                        Text("Good Morning,")
                            .font(.system(.title, design:.serif))
                            .padding(10)
                        Text("Mikaela")
                            .font(.largeTitle.bold())
                            .padding(.leading)
                    }
                    Spacer()
                    Image("profile")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 70, height: 70)
                        .clipShape(RoundedRectangle(cornerRadius:12))
                        .padding(10)
                }
                
                // Search bar
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white)
                    .fill(Color(.systemGray6))
                    .frame(height:50)
                    .frame(height:50)
                    .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
                    .overlay(
                        HStack{
                            Image(systemName:"magnifyingglass")
                                .foregroundColor(.gray)
                            Text("Search")
                                .foregroundColor(.gray)
                            Spacer()
                        }
                        .padding(.horizontal)
                    )
                
                // Goals
                VStack(alignment: .leading, spacing: 22){
                    Text("Today's Goal")
                        .font(.title2.bold())
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .center)
                    
                    HStack(spacing: 16){
                        GoalCard(title: "4 Miles", subtitle: "@Thames Route", systemIcon: "figure.run")
                        GoalCard(title:"2 Miles", subtitle: "@River Lea", systemIcon: "figure.rower")
                    }
                }
                .padding()
                .frame(maxWidth: .infinity, minHeight: 250, alignment: .center)
                .background(
                    LinearGradient(colors:[.blue,.pink],
                                   startPoint:.topLeading,
                                   endPoint:.bottomTrailing)
                    .cornerRadius(20)
                )
                
                // Stats
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                    StatCard(icon: "heart.fill", value: "68 Bpm", color: .purple)
                    StatCard(icon: "flame.fill", value: "0 Kcal", color: .orange)
                    StatCard(icon: "scalemass.fill", value: "73 Kg", color: .green)
                    StatCard(icon: "bed.double.fill", value: "6.2 Hr", color: .blue)
                }
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .frame(maxHeight: .infinity)
        }
        .background(Color(.systemGray6).ignoresSafeArea())
    }
}

struct GoalCard: View {
    var title:String
    var subtitle:String
    var systemIcon:String
    
    var body:some View {
        VStack(alignment: .center, spacing: 8){
            Image(systemName:systemIcon)
                .font(.system(size: 50))
                .foregroundColor(.white.opacity(0.9))
            Text(title)
                .font(.headline)
                .bold()
                .foregroundColor(.white)
            Text(subtitle)
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.8))
        }
        .frame(maxWidth:.infinity, minHeight:170)
        .background(Color.white.opacity(0.15))
        .cornerRadius(18)
    }
}

struct StatCard: View {
    var icon: String
    var value: String
    var color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.title2)
            Text(value)
                .font(.headline)
                .foregroundColor(.black)
        }
        .frame(maxWidth: .infinity, minHeight: 90)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
    }
}

#Preview {
    ContentView()
}
