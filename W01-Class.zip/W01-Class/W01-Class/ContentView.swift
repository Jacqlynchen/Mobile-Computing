//
//  ContentView.swift
//  W01-Class
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(){
            Image("jacq")
                .resizable()
                .frame(width: 200, height: 200)
                .scaledToFit()
                .clipShape(Circle())
                
                .padding()
            let name = "Jacqlyn Chen"
            var age = 19
            
            Text("Hi, I'm \(name)")
                .font(.headline)
                .foregroundStyle(.blue)
                .background(Color.yellow)
                .shadow(radius: 2)
            Text("My age is \(age)")
                .font(.headline)
                .foregroundStyle(.red)
                .shadow(radius: 2)
                .padding()
            Text("💕🙈☺️")
                .font(.largeTitle)
        }
            //        HStack(spacing: 15){
            //
            //            VStack (){
            //                Text("😩")
            //                Text("😩")
            //                Text("😩")
            //            }
            //            VStack (){
            //                Text("👀")
            //                Text("👀")
            //                Text("👀")
            //            }
            //            VStack (){
            //                Text("💕")
            //                Text("💕")
            //                Text("💕")
            //            }
            //        }
            //
            //        VStack(alignment: .leading, spacing: 15) {
            //
            //            VStack(spacing: 12){
            //                Text("ter")
            //                Text("se")
            //                Text("rah👀")
            //            }
            //
            //            Text("Hello, world!")
            //                .font(.largeTitle)
            //                .fontWeight(.bold)
            //                .padding(.horizontal)
            //
            //            Text("Declareative UI")
            //                .multilineTextAlignment(.center)
            //                .padding()
            //                .font(.headline)
            //                .background(.ultraThinMaterial)
            //                .clipShape(RoundedRectangle(cornerRadius: 16))
            //
            //            Image(systemName: "sparkles")
            //                .imageScale(.large)
            //                .font(.system(size: 100))
            //                .padding()
            //                .foregroundColor(.yellow)
            //                .overlay(content: {
            //                    Circle().strokeBorder(.gray.opacity(0.3),lineWidth: 2)
            //                })
            //        }
            //
            //    }
            //    let name = "Alice"
            //    var age = 20
            //    func greet() {
            //        print("Hello, \(name), age \(age)")
            
        }
    }

#Preview {
    ContentView()
}
