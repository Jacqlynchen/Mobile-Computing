//
//  W01_ClassApp.swift
//  W01-Class
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_ClassApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
