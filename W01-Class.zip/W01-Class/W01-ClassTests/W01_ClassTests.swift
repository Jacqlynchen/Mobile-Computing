//
//  W01_ClassTests.swift
//  W01-ClassTests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_Class

struct W01_ClassTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
