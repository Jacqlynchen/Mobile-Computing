//
//  Movie.swift
//  W05_class
//
//  Created by student on 09/10/25.
//

import Foundation

struct Movie: Identifiable, Codable, Hashable{
    // id pakai  let soalnya ga akan ada penambahan genre/movie
    var id = UUID()
    var title: String
    var genre: Genre //Linked Model
    var isFavourite: Bool = false
    
}
