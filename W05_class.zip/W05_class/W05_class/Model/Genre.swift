//
//  Genre.swift
//  W05_class
//
//  Created by student on 09/10/25.
//

import Foundation

struct Genre: Identifiable, Codable, Hashable {
    let id = UUID()
    var name: String
    var colorHex: String
    
    static let all: [Genre] = [
        Genre(name: "Action", colorHex: "#FF4500"),
        Genre(name: "Romance", colorHex: "#4B0082")
    ]
}
