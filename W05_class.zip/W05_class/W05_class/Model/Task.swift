//
//  Task.swift
//  W05_class
//
//  Created by student on 09/10/25.
//

// Model <<<
// ViewModel
// View
// coding struktural biasanya diawali dengan pembuatan model terlebih dahulu

import Foundation

struct Task: Identifiable, Codable, Hashable{
    var id = UUID() // var id: UUID = UUID [generate random]
    var title: String
    var isCompleted: Bool = false
}
