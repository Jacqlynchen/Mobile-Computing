//
//  Fruit.swift
//  W05_class
//
//  Created by student on 09/10/25.
//

import Foundation

struct Fruit: Identifiable, Codable, Hashable {
    let UUID: UUID// Universal Unique ID
    let id: String
    let name: String
    let color: String
    
    // Identifiable = Who's who
    // Codable = Struct ini bisa komunikasi dengan file lain / API
    // Hashable = Swift bisa melakukan komparasi / track codenya
    
//    forEach (fruits, id: \.id) (fruit) in{
//        
//    }
}
