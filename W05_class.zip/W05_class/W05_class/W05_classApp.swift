//
//  W05_classApp.swift
//  W05_class
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct W05_classApp: App {
    var body: some Scene {
        WindowGroup {
            MovieHomeView()
        }
    }
}
