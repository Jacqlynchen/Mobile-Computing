//
//  W05_classTests.swift
//  W05_classTests
//
//  Created by student on 09/10/25.
//

import Testing
@testable import W05_class

struct W05_classTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
