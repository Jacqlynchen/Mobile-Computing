//
//  LoadingState.swift
//  W06_class
//
//  Created by student on 16/10/25.
//


//
//  ContentView.swift
//  W06_class
//
//  Created by student on 16/10/25.
//

import SwiftUI

// MARK: - Enum Definitions

enum LoadingState {
    case idle
    case loading
    case success(data: String)
    case error(message: String)
}

enum Grade: String, CaseIterable {
    case A, B, C, D, E
    
    var color: Color {
        switch self {
        case .A: return .green
        case .B: return .blue
        case .C: return .red
        case .D: return .gray
        case .E: return .yellow
        }
    }
}

// enum APIResponse { ... } // Not used

// MARK: - Observable Class

class Counter: ObservableObject {
    @Published var count: Int = 0
    func increment() { count += 1 }
    func decrement() { count -= 1 }
}

struct ContentView: View {
    
    // MARK: - State Variables
    
    @State private var fruits: [String] = ["Apple", "Orange", "Banana"]
    
    @State private var scores: [String: Int] = [
        "Alice": 30,
        "Mahami": 50,
        "Sutris": 20
    ]
    @State private var name: String = ""
    
    @StateObject private var counterA = Counter()
    @State private var counterB: Counter? = nil
    
    @State private var programmingLanguage: Set<String> = ["Swift", "Python", "JavaScript"]
    @State private var newLang: String = ""
    
    @State private var point: (x: Int, y: Int) = (x: 0, y: 0)
    
    @State private var grade: Grade = .A
    @State private var state: LoadingState = .idle
    
    // MARK: - Body
    
    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                
                // MARK: - Array Section
                VStack(spacing: 15) {
                    Text("Array of Fruits")
                        .font(.largeTitle)
                    
                    HStack {
                        ForEach(fruits, id: \.self) { fruit in
                            Text(fruit)
                                .padding(10)
                                .background(Color.orange.opacity(0.3))
                                .clipShape(Capsule())
                        }
                    }
                    
                    HStack {
                        Button("Add Fruit") {
                            fruits.append("Banana")
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Button("Remove Last") {
                            if !fruits.isEmpty {
                                fruits.removeLast()
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                
                // MARK: - Dictionary Section
                VStack(alignment: .leading, spacing: 15) {
                    Text("Dictionary of Scores")
                        .font(.largeTitle)
                    
                    VStack(alignment: .leading) {
                        ForEach(scores.sorted(by: { $0.key < $1.key }), id: \.key) { name, score in
                            HStack {
                                Text(name)
                                Spacer()
                                Text("\(score)").bold()
                            }
                        }
                    }
                    .padding(10)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(10)
                    
                    HStack {
                        Button("Increase Buttris' Score!") {
                            scores["Buttris", default: 0] += 5
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Button("Delete All Scores") {
                            scores.removeAll()
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    
                    VStack(spacing: 10) {
                        TextField("Add Student", text: $name)
                            .padding()
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                        Button("Add") {
                            if !name.isEmpty {
                                scores[name] = 5
                                name = ""
                            }
                        }
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                
                // MARK: - Class Section
                VStack(spacing: 15) {
                    Text("Class Example (Counter)")
                        .font(.title)
                    
                    Text("Counter A: \(counterA.count)")
                    Text("Counter B: \(counterB?.count ?? 9)")
                        .foregroundColor(counterB == nil ? .red : .primary)
                    
                    HStack {
                        Button("+A") { counterA.increment() }
                        Button("-A") { counterA.decrement() }
                        
                        Button(counterB == nil ? "Clone A to B" : "Unlink B") {
                            if counterB == nil {
                                counterB = counterA
                            } else {
                                counterB = nil
                            }
                        }
                        .buttonStyle(.bordered)
                        
                        Button("+B") { counterB?.increment() }
                    }
                }
                .padding()
                .background(Color.green.opacity(0.1))
                .cornerRadius(10)
                
                // MARK: - Set Section
                VStack(spacing: 15) {
                    Text("Set of Programming Languages")
                        .font(.largeTitle)
                    
                    HStack {
                        ForEach(Array(programmingLanguage), id: \.self) { lang in
                            Text(lang)
                                .padding(8)
                                .background(Color.green.opacity(0.5))
                                .clipShape(Capsule())
                        }
                    }
                    
                    HStack(spacing: 10) {
                        TextField("Enter new language", text: $newLang)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .frame(width: 200)
                        
                        Button("Add") {
                            if !newLang.isEmpty {
                                programmingLanguage.insert(newLang)
                                newLang = ""
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                .padding()
                .background(Color.yellow.opacity(0.1))
                .cornerRadius(10)
                
                // MARK: - Tuple Section
                VStack(spacing: 10) {
                    Text("Ini adalah Tuple")
                        .font(.largeTitle)
                    
                    Text("Nilai sekarang XY: \(point.x), \(point.y)")
                    
                    HStack {
                        Button("Kanan 10 Langkah") {
                            point.x += 10
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Button("Kiri 10 Langkah") {
                            point.y -= 10
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                .padding()
                .background(Color.pink.opacity(0.1))
                .cornerRadius(10)
                
                // MARK: - Enum Grade Section
                VStack(spacing: 10) {
                    Text("Enum Grade Picker")
                        .font(.title2)
                    
                    Picker("Select Grade", selection: $grade) {
                        ForEach(Grade.allCases, id: \.self) { g in
                            Text(g.rawValue)
                        }
                    }
                    .pickerStyle(.segmented)
                    
                    Text("Your Grade: \(grade.rawValue)")
                        .foregroundColor(grade.color)
                        .bold()
                }
                .padding()
                .background(Color.orange.opacity(0.1))
                .cornerRadius(10)
                
                // MARK: - LoadingState Section
                VStack(spacing: 10) {
                    Text("Enum State Handling")
                        .font(.title2)
                    
                    Group {
                        switch state {
                        case .idle:
                            Text("Tap to start loading")
                                .foregroundColor(.gray)
                        case .loading:
                            ProgressView("Loading...")
                        case .success(let data):
                            Text(data)
                                .foregroundColor(.green)
                        case .error(let message):
                            Text("Error: \(message)")
                                .foregroundColor(.red)
                        }
                    }
                    
                    HStack {
                        Button("Start") { state = .loading }
                        Button("Success") {
                            state = .success(data: "KTP mu telah diupload untuk pinjol!")
                        }
                        Button("Error") {
                            state = .error(message: "Data tidak valid")
                        }
                    }
                }
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(10)
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
