//
//  W06_classApp.swift
//  W06_class
//
//  Created by student on 16/10/25.
//

import SwiftUI

@main
struct W06_classApp: App {
    let persistence = PersistanceController.shared
    
    var body: some Scene {
        WindowGroup {
            let vm = CoreDataStudentViewModel(context: persistence.container.viewContext)
            CoreDataStudentView(vm:vm)
            ContentView()
        }
    }
}
