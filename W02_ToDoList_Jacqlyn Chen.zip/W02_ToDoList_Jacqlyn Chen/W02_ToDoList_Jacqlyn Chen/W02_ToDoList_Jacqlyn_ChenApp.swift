//
//  W02_ToDoList_Jacqlyn_ChenApp.swift
//  W02_ToDoList_Jacqlyn Chen
//
//  Created by Jennifer Alicia Litan on 22/09/25.
//

import SwiftUI

@main
struct W02_ToDoList_Jacqlyn_ChenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
