//
//  ContentView.swift
//  W02_ToDoList_Jacqlyn Chen
//
//  Created by Jacqlyn Chen on 22/09/25.
//

import SwiftUI

struct ContentView: View {
    
    @State private var tasks: [String] = [
        "Homework MobCom Luvv",
        "Golf 25-9-2025",
        "Cuci kamar mandi",
        "Homework ISSG",
        "Ganti Sprei"
    ]
    
    // Status task yang sudah selesai
    @State private var done: Set<Int> = []
    
    // Input task baru
    @State private var newTask = ""
    
    // Untuk edit
    @State private var editIndex: Int? = nil
    @State private var editText: String = ""
    
    // Progress otomatis
    private var progress: Double {
        guard !tasks.isEmpty else { return 0 }
        return Double(done.count) / Double(tasks.count)
    }
    
    var body: some View {
        VStack(spacing: 16) {
            
            // Header
            HStack {
                Text("My To-Do List")
                    .font(.title)
                    .fontWeight(.bold)
                Spacer()
            }
            .padding(.horizontal)
            
            // Input Edit Task di atas
            if let index = editIndex {
                HStack {
                    TextField("Edit Task...", text: $editText)
                        .textFieldStyle(.roundedBorder)
                    
                    Button("Save") {
                        let t = editText.trimmingCharacters(in: .whitespacesAndNewlines)
                        if !t.isEmpty {
                            tasks[index] = t
                            editIndex = nil
                            editText = ""
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .foregroundColor(.white)
                    .background(Color.orange)
                    .cornerRadius(8)
                    
                    Button("Cancel") {
                        editIndex = nil
                        editText = ""
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .foregroundColor(.white)
                    .background(Color.gray)
                    .cornerRadius(8)
                }
                .padding(.horizontal)
            }
            
            // Input tambah task baru
            HStack {
                TextField("Add New Task...", text: $newTask)
                    .textFieldStyle(.roundedBorder)
                
                Button("Add") {
                    let t = newTask.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !t.isEmpty {
                        tasks.append(t)
                        newTask = ""
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(8)
            }
            .padding(.horizontal)
            
            // List task
            List {
                ForEach(tasks.indices, id: \.self) { i in
                    HStack {
                        Button {
                            if done.contains(i) {
                                done.remove(i)
                            } else {
                                done.insert(i)
                            }
                        } label: {
                            Image(systemName: done.contains(i) ? "checkmark.circle.fill" : "circle")
                                .foregroundColor(done.contains(i) ? .green : .gray)
                        }
                        .buttonStyle(.plain)
                        
                        Text(tasks[i])
                            .strikethrough(done.contains(i), color: .gray)
                            .foregroundColor(done.contains(i) ? .gray : .primary)
                        
                        Spacer()
                        
                        // Tombol edit ✏️
                        Button {
                            editIndex = i
                            editText = tasks[i]
                        } label: {
                            Image(systemName: "pencil.circle")
                                .foregroundColor(.orange)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .onDelete { indexSet in
                    tasks.remove(atOffsets: indexSet)
                }
            }
            
            // Progress Bar di bawah
            VStack(spacing: 8) {
                ProgressView(value: progress)
                    .tint(.green) // warna hijau
                    .scaleEffect(x: 1, y: 2, anchor: .center) // lebih tebal
                
                Text("Progress: \(done.count)/\(tasks.count) • \(Int(progress * 100))%")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal)
            .padding(.bottom, 12)
        }
    }
}

#Preview {
    ContentView()
}
