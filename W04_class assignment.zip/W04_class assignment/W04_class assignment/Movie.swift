//
//  Movie.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//

import Foundation

struct Movie: Identifiable, Codable, Hashable {
    let id = UUID()
    let title: String
    let genre: String
    let poster: String // either local asset name or full URL
    let synopsis: String
}
