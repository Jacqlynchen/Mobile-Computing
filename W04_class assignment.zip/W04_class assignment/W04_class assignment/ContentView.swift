//
//  ContentView.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var store: MovieStore
    
    var body: some View {
        NavigationStack {
            MovieGridView(store: store)
        }
    }
}

#Preview {
    ContentView(store: MovieStore())
}
