//
//  MovieCardView.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//
import SwiftUI

struct MovieCardView: View {
    let movie: Movie
    @Binding var isFavorite: Bool   // 🔹 binding untuk favorit
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            
            VStack(alignment: .leading, spacing: 0) {
                // Poster
                Image(movie.poster)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 200)
                    .clipped()
                
                // Text bawah poster
                VStack(alignment: .leading, spacing: 4) {
                    Text(movie.title)
                        .font(.headline)
                        .foregroundColor(.black)
                    Text(movie.genre)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.white)
            }
            
            // 🔹 Tombol love di pojok kanan atas
            Button {
                isFavorite.toggle()
            } label: {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .padding(10)
                    .foregroundColor(.red)
                    .background(Color.white.opacity(0.7))
                    .clipShape(Circle())
                    .shadow(radius: 3)
            }
            .padding(8)
        }
        .cornerRadius(12)
        .shadow(radius: 6)
    }
}


