//
//  MovieStore.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//
import Foundation
import Combine

class MovieStore: ObservableObject {
    @Published var movies: [Movie] = []
    @Published var favorites: Set<UUID> = []
    
    init() {
        loadSamples()
    }
    
    func loadSamples() {
        movies = [
            Movie(title: "Inception", genre: "Sci-Fi", poster: "inception"),
            Movie(title: "Interstellar", genre: "Adventure", poster: "interstellar"),
            Movie(title: "The Dark Knight", genre: "Action", poster: "darkkight"),
            Movie(title: "La La Land", genre: "Romance", poster: "lalaland"),
            Movie(title: "Parasite", genre: "Thriller", poster:"parasite")
        ]
    }
    
    func toggleFavorite(_ movie: Movie) {
            let id = movie.id
            if favorites.contains(id) {
                favorites.remove(id)
            } else {
                favorites.insert(id)
            }
        }
}
