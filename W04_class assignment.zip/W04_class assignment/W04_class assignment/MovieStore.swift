//
//  MovieStore.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//
import Foundation
import Combine

class MovieStore: ObservableObject {
    @Published var movies: [Movie] = []
    @Published var favorites: Set<UUID> = []
    
    init() {
        loadSamples()
    }
    
    func loadSamples() {
        movies = [
            Movie(title: "Inception", genre: "Sci-Fi", poster: "inception", synopsis: "Dom Cobb, seorang pencuri profesional, memiliki kemampuan untuk masuk ke mimpi orang lain dan mencuri rahasia berharga. Ia ditugaskan melakukan inception, menamakan sebuah ide ke dalam pikiran target."),
            Movie(title: "Interstellar", genre: "Adventure", poster: "interstellar", synopsis: "Di masa depan bumi yang semakin rusak, sekelompok astronot melakukan perjalanan melalui lubang cacing untuk mencari planet baru demi kelangsungan hidup umat manusia."),
            Movie(title: "The Dark Knight", genre: "Action", poster: "darkkight", synopsis: "Batman berhadapan dengan Joker, penjahat sadis yang ingin menjerumuskan Gotham ke dalam kekacauan. Pertarungan ini menguji batas moral Batman sebagai pahlawan."
                 ),
            Movie(title: "La La Land", genre: "Romance", poster: "lalaland", synopsis: "Kisah cinta antara Mia, seorang aktris muda, dan Sebastian, seorang pianis jazz. Mereka berjuang mengejar mimpi masing-masing di Los Angeles, meski harus menghadapi pilihan sulit."),
            Movie(title: "Parasite", genre: "Thriller", poster:"parasite", synopsis: "Keluarga miskin Kim menyusup ke rumah keluarga kaya Park dengan berpura-pura sebagai pekerja profesional. Namun rencana mereka berubah menjadi tragedi penuh ketegangan."
                 )
        ]
    }
    
    func toggleFavorite(_ movie: Movie) {
            let id = movie.id
            if favorites.contains(id) {
                favorites.remove(id)
            } else {
                favorites.insert(id)
            }
        }
}
