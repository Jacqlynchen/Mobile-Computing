//
//  MovieDetailView.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    @ObservedObject var store: MovieStore
    var isFav: Bool { store.favorites.contains(movie.id) }
    var body: some View {
        VStack(spacing: 16) {
            if movie.poster.starts(with: "http"), let url = URL(string: movie.poster) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty: ProgressView()
                    case .success(let img): img.resizable().scaledToFit()
                    case .failure: Image("placeholder").resizable().scaledToFit()
                    @unknown default: Color.gray
                    }
                }
                .frame(height: 320)
                .cornerRadius(12)
            } else {
                Image(movie.poster).resizable().scaledToFit().cornerRadius(12)
            }
            HStack {
                VStack(alignment: .leading) {
                    Text(movie.title).font(.title).bold()
                    Text(movie.genre).font(.subheadline).foregroundColor(.secondary)
                }
                Spacer()
                Button { store.toggleFavorite(movie) } label: {
                    Image(systemName: isFav ? "heart.fill" : "heart")
                        .font(.title2)
                }
            }.padding(.horizontal)
            Spacer()
        }
        .padding()
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
