//
//  MovieDetailView.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//
import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    @ObservedObject var store: MovieStore
    var isFav: Bool { store.favorites.contains(movie.id) }
    
    var body: some View {
        ScrollView {   // 🔹 pakai ScrollView kalau sinopsis panjang
            VStack(spacing: 16) {
                
                Image(movie.poster)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(12)
                    .frame(maxHeight: 320)
                
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(movie.title)
                            .font(.title)
                            .bold()
                        Text(movie.genre)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                    Button { store.toggleFavorite(movie) } label: {
                        Image(systemName: isFav ? "heart.fill" : "heart")
                            .font(.title2)
                            .foregroundColor(.red)
                    }
                }
                .padding(.horizontal)
                
                // 🔹 Sinopsis
                Text(movie.synopsis)
                    .font(.body)
                    .padding()
                    .multilineTextAlignment(.leading)
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
