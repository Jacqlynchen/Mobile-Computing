//
//  MovieGridView.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//
import SwiftUI

struct MovieGridView: View {
    @ObservedObject var store: MovieStore
    @State private var searchText = ""   // state untuk search
    
    // Filtered movies
    var filteredMovies: [Movie] {
        if searchText.isEmpty {
            return store.movies
        } else {
            return store.movies.filter { movie in
                movie.title.localizedCaseInsensitiveContains(searchText) ||
                movie.genre.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    // Layout grid 2 kolom
    let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            
            // 🔹 Judul UCFlix
            Text("🎬UCFlix")
                .font(.largeTitle)
                .bold()
                .padding(.horizontal)
            
            // 🔹 Search bar custom
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                TextField("Search movies or genres", text: $searchText)
                    .textFieldStyle(PlainTextFieldStyle())
            }
            .padding(10)
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)
            
            // 🔹 Scrollable grid
            ScrollView {
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(filteredMovies) { movie in
                        let isFav = Binding(
                            get: { store.favorites.contains(movie.id) },
                            set: { newValue in
                                if newValue {
                                    store.favorites.insert(movie.id)
                                } else {
                                    store.favorites.remove(movie.id)
                                }
                            }
                        )
                        
                        NavigationLink(destination: MovieDetailView(movie: movie, store: store)) {
                            MovieCardView(movie: movie, isFavorite: isFav)  // 🔹 pass binding
                        }
                    }
                }
                .padding()
            }
        }
    }
}
