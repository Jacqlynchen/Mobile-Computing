//
//  W04_class_assignmentApp.swift
//  W04_class assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct UCFlixApp: App {
    @StateObject private var store = MovieStore()
    
    var body: some Scene {
        WindowGroup {
            ContentView(store:store)
        }
    }
}
