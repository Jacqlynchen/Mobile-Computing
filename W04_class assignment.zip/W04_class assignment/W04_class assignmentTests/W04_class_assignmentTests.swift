//
//  W04_class_assignmentTests.swift
//  W04_class assignmentTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import W04_class_assignment

struct W04_class_assignmentTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
