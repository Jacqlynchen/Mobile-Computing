//
//  Assignment_Week3_Jessica_Laurentia_TedjaTests.swift
//  Assignment_Week3_Jessica Laurentia TedjaTests
//
//  Created by student on 25/09/25.
//

import Testing
@testable import Assignment_Week3_Jessica_Laurentia_Tedja

struct Assignment_Week3_Jessica_Laurentia_TedjaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
