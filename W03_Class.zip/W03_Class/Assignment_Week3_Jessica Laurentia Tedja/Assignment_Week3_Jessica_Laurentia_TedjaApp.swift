//
//  Assignment_Week3_Jessica_Laurentia_TedjaApp.swift
//  Assignment_Week3_Jessica Laurentia Tedja
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct Assignment_Week3_Jessica_Laurentia_TedjaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
